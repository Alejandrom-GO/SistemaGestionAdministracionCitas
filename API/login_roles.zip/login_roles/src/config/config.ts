export default {
    jwtSecret: 'UTXJ2021'
  };
  